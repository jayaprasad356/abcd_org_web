package qrcoba.w3engineers.com.qrcoba.helpers.constant;

public interface PreferenceKey {
    String PLAY_SOUND = "play_sound";
    String VIBRATE = "vibrate";
    String SAVE_HISTORY = "save_history";
    String COPY_TO_CLIPBOARD = "copy_to_clipboard";
}
