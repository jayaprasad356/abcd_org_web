package qrcoba.w3engineers.com.qrcoba.helpers.constant;

public interface ColumnNames {
    String ID = "id";
}
