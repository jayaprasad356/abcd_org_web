package qrcoba.w3engineers.com.qrcoba.ui.Interface;

public interface InterstitialAdView {
    void position(int position, String type, String id);
}
