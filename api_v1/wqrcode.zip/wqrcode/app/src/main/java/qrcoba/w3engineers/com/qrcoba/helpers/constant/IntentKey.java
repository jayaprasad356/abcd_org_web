package qrcoba.w3engineers.com.qrcoba.helpers.constant;

public interface IntentKey {
    String MODEL = "model";
    String IS_HISTORY = "is_history";
    String IS_PICKED_FROM_GALLERY = "is_picked_from_gallery";
}
