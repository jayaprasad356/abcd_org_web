package qrcoba.w3engineers.com.qrcoba.ui.Interface;

public interface VideoAds {
    void videoAdClick(String type);
}
