package qrcoba.w3engineers.com.qrcoba.helpers.constant;

public interface TableNames {
    String CODES = "CODES";
}
